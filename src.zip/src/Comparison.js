export default function Comparison({ cities }) {
  return (
    <div className="comparison">
      {cities.map((data, idx) => (
        <div className="weather-box" key={idx}>
          <h4>{data.name}</h4>
          <p>Temp: {data.main.temp}°C</p>
          <p>Humidity: {data.main.humidity}%</p>
          <p>{data.weather[0].description}</p>
        </div>
      ))}
    </div>
  );
}
