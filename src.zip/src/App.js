import React, { useState, useEffect } from 'react';
import CityWeather from './CityWeather';
import Favorites from './Favorites';
import Comparison from './Comparison';
import './styles.css';
import { fetchWeather } from './api';

export default function App() {
  const [favorites, setFavorites] = useState([]);
  const [comparison, setComparison] = useState([]);

  useEffect(() => {
    const stored = localStorage.getItem('favorites');
    if (stored) setFavorites(JSON.parse(stored));
  }, []);

  const saveFavorite = (city) => {
    if (!favorites.includes(city)) {
      const updated = [...favorites, city];
      setFavorites(updated);
      localStorage.setItem('favorites', JSON.stringify(updated));
    }
  };

  const handleSelect = async (data) => {
    if (comparison.length < 2) {
      setComparison([...comparison, data]);
    } else {
      setComparison([data]);
    }
  };

  const handleFavoriteClick = async (city) => {
    const data = await fetchWeather(city);
    handleSelect(data);
  };

  return (
    <div className="app-container">
      <div className="left-panel">
        <h1>Weather Checker 🌤️</h1>
        <CityWeather onSelect={handleSelect} onSave={saveFavorite} />
        <Favorites favorites={favorites} onSelect={handleFavoriteClick} />
      </div>

      <div className="right-panel">
        {comparison.length > 0 && <Comparison cities={comparison} />}
      </div>
    </div>
  );
}
