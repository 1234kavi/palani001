const API_KEY = '1aec0bd4925cd50b864eaa941022da0b'; // Replace with your OpenWeather API key

export const fetchWeather = async (city) => {
  const res = await fetch(
    `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_KEY}&units=metric`
  );
  if (!res.ok) throw new Error('City not found');
  return res.json();
};
