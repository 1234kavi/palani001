import React, { useState } from 'react';
import { fetchWeather } from './api';

export default function CityWeather({ onSelect, onSave }) {
  const [city, setCity] = useState('');
  const [weather, setWeather] = useState(null);
  const [error, setError] = useState(null);

  const handleSearch = async () => {
    try {
      setError(null);
      const data = await fetchWeather(city);
      setWeather(data);
      onSelect(data);
    } catch (err) {
      setError('City not found');
    }
  };

  return (
    <div className="card">
      <h3>Check Weather</h3>
      <input
        type="text"
        placeholder="Enter city"
        value={city}
        onChange={(e) => setCity(e.target.value)}
      />
      <button onClick={handleSearch}>Search</button>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      {weather && (
  <div className="weather-box">
    <p><strong>{weather.name}</strong></p>
    <img
      src={`https://openweathermap.org/img/wn/${weather.weather[0].icon}@2x.png`}
      alt="weather icon"
    />
    <p>Temp: {weather.main.temp}°C</p>
    <p>Humidity: {weather.main.humidity}%</p>
    <p>{weather.weather[0].description}</p>
    <button onClick={() => onSave(weather.name)}>Save</button>
  </div>
)}

    </div>
  );
}
