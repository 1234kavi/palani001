export default function Favorites({ favorites, onSelect }) {
  return (
    <div className="card">
      <h3>Favorite Cities</h3>
      {favorites.length === 0 ? (
        <p>No favorites yet.</p>
      ) : (
        favorites.map((city, idx) => (
          <button key={idx} onClick={() => onSelect(city)}>
            {city}
          </button>
        ))
      )}
    </div>
  );
}
